@extends('layouts.app')
@section('title', 'Configuración de Empresa')
@section('page-title', 'Empresa · Configuración')

@section('content')

@if(session('success'))
<div class="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400
            rounded-xl px-5 py-3 mb-5 flex items-center gap-3">
    <i class="fas fa-check-circle"></i> {{ session('success') }}
</div>
@endif

{{-- Alerta resolución DIAN --}}
@if($empresa->resolucion_vencimiento)
    @if(!$empresa->resolucion_vigente)
    <div class="bg-red-500/10 border border-red-500/30 text-red-400
                rounded-xl px-5 py-4 mb-5 flex items-center gap-3">
        <i class="fas fa-exclamation-triangle text-lg"></i>
        <div>
            <div class="font-semibold">¡Resolución DIAN vencida!</div>
            <div class="text-sm opacity-80">Venció el {{ $empresa->resolucion_vencimiento->format('d/m/Y') }}. Renueva urgentemente para poder facturar.</div>
        </div>
    </div>
    @elseif($empresa->dias_para_vencer <= 30)
    <div class="bg-amber-500/10 border border-amber-500/30 text-amber-400
                rounded-xl px-5 py-4 mb-5 flex items-center gap-3">
        <i class="fas fa-clock text-lg"></i>
        <div>
            <div class="font-semibold">Resolución DIAN próxima a vencer</div>
            <div class="text-sm opacity-80">Vence en {{ $empresa->dias_para_vencer }} días ({{ $empresa->resolucion_vencimiento->format('d/m/Y') }}). Renueva pronto.</div>
        </div>
    </div>
    @endif
@endif

<form method="POST" action="{{ route('empresa.update') }}" enctype="multipart/form-data">
    @csrf @method('PUT')

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">

        {{-- COLUMNA IZQUIERDA --}}
        <div class="lg:col-span-2 space-y-4">

            {{-- SECCIÓN 1: Identificación --}}
            <div class="bg-[#141c2e] border border-[#1e2d47] rounded-2xl p-6">
                <h2 class="font-display font-bold text-base mb-4 flex items-center gap-2">
                    <span class="w-6 h-6 bg-amber-500 rounded-lg flex items-center justify-center
                                 text-black text-xs font-black">1</span>
                    Identificación de la Empresa
                </h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="sm:col-span-2">
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                            Razón Social *
                        </label>
                        <input type="text" name="razon_social"
                               value="{{ old('razon_social', $empresa->razon_social) }}"
                               data-uppercase
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                      text-sm focus:outline-none focus:border-amber-500
                                      @error('razon_social') border-red-500 @enderror"
                               style="color:#e2e8f0">
                        @error('razon_social') <p class="text-red-400 text-xs mt-1">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                            Nombre Comercial
                        </label>
                        <input type="text" name="nombre_comercial"
                               value="{{ old('nombre_comercial', $empresa->nombre_comercial) }}"
                               data-uppercase
                               placeholder="NOMBRE COMERCIAL"
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                      text-sm placeholder-slate-600 focus:outline-none focus:border-amber-500"
                               style="color:#e2e8f0">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                            Tipo de Persona
                        </label>
                        <select name="tipo_persona"
                                class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                       text-sm focus:outline-none focus:border-amber-500"
                                style="color:#e2e8f0">
                            <option value="juridica" {{ old('tipo_persona',$empresa->tipo_persona)=='juridica' ? 'selected':'' }}>Persona Jurídica</option>
                            <option value="natural"  {{ old('tipo_persona',$empresa->tipo_persona)=='natural'  ? 'selected':'' }}>Persona Natural</option>
                        </select>
                    </div>
                    <div class="grid grid-cols-3 gap-2">
                        <div class="col-span-2">
                            <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">NIT *</label>
                            <input type="text" name="nit"
                                   value="{{ old('nit', $empresa->nit) }}"
                                   placeholder="900000000"
                                   data-numeric
                                   class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                          text-sm placeholder-slate-600 focus:outline-none focus:border-amber-500
                                          @error('nit') border-red-500 @enderror"
                                   style="color:#e2e8f0">
                            @error('nit') <p class="text-red-400 text-xs mt-1">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">DV</label>
                            <input type="text" name="digito_verificacion" maxlength="1"
                                   value="{{ old('digito_verificacion', $empresa->digito_verificacion) }}"
                                   placeholder="0"
                                   data-numeric
                                   class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                          text-sm placeholder-slate-600 focus:outline-none focus:border-amber-500"
                                   style="color:#e2e8f0">
                        </div>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                            Régimen Tributario
                        </label>
                        <select name="regimen"
                                class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                       text-sm focus:outline-none focus:border-amber-500"
                                style="color:#e2e8f0">
                            <option value="responsable_iva" {{ old('regimen',$empresa->regimen)=='responsable_iva' ? 'selected':'' }}>Responsable de IVA</option>
                            <option value="simple"          {{ old('regimen',$empresa->regimen)=='simple'          ? 'selected':'' }}>Régimen Simple</option>
                        </select>
                    </div>
                </div>
            </div>

            {{-- SECCIÓN 2: Contacto --}}
            <div class="bg-[#141c2e] border border-[#1e2d47] rounded-2xl p-6">
                <h2 class="font-display font-bold text-base mb-4 flex items-center gap-2">
                    <span class="w-6 h-6 bg-amber-500 rounded-lg flex items-center justify-center
                                 text-black text-xs font-black">2</span>
                    Contacto y Ubicación
                </h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">Email</label>
                        <input type="email" name="email"
                               value="{{ old('email', $empresa->email) }}"
                               placeholder="info@empresa.com"
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                      text-sm placeholder-slate-600 focus:outline-none focus:border-amber-500"
                               style="color:#e2e8f0">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">Teléfono</label>
                        <input type="text" name="telefono"
                               value="{{ old('telefono', $empresa->telefono) }}"
                               placeholder="601 1234567"
                               data-numeric
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                      text-sm placeholder-slate-600 focus:outline-none focus:border-amber-500"
                               style="color:#e2e8f0">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">Celular</label>
                        <input type="text" name="celular"
                               value="{{ old('celular', $empresa->celular) }}"
                               placeholder="300 1234567"
                               data-numeric
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                      text-sm placeholder-slate-600 focus:outline-none focus:border-amber-500"
                               style="color:#e2e8f0">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">Sitio Web</label>
                        <input type="text" name="sitio_web"
                               value="{{ old('sitio_web', $empresa->sitio_web) }}"
                               placeholder="www.empresa.com"
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                      text-sm placeholder-slate-600 focus:outline-none focus:border-amber-500"
                               style="color:#e2e8f0">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">Departamento</label>
                        <input type="text" name="departamento"
                               value="{{ old('departamento', $empresa->departamento) }}"
                               placeholder="CÓRDOBA"
                               data-uppercase
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                      text-sm placeholder-slate-600 focus:outline-none focus:border-amber-500"
                               style="color:#e2e8f0">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">Municipio</label>
                        <input type="text" name="municipio"
                               value="{{ old('municipio', $empresa->municipio) }}"
                               placeholder="MONTERÍA"
                               data-uppercase
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                      text-sm placeholder-slate-600 focus:outline-none focus:border-amber-500"
                               style="color:#e2e8f0">
                    </div>
                    <div class="sm:col-span-2 lg:col-span-3">
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">Dirección</label>
                        <input type="text" name="direccion"
                               value="{{ old('direccion', $empresa->direccion) }}"
                               placeholder="CRA 5 # 10-20"
                               data-uppercase
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                      text-sm placeholder-slate-600 focus:outline-none focus:border-amber-500"
                               style="color:#e2e8f0">
                    </div>
                </div>
            </div>

            {{-- SECCIÓN 3: DIAN --}}
            <div class="bg-[#141c2e] border border-[#1e2d47] rounded-2xl p-6">
                <h2 class="font-display font-bold text-base mb-4 flex items-center gap-2">
                    <span class="w-6 h-6 bg-amber-500 rounded-lg flex items-center justify-center
                                 text-black text-xs font-black">3</span>
                    Resolución DIAN — Factura Electrónica
                </h2>

                <div class="flex items-center gap-3 mb-5 p-3 bg-[#1a2235] rounded-xl">
                    <input type="checkbox" name="factura_electronica" value="1"
                           id="factura_electronica"
                           class="w-4 h-4 accent-amber-500"
                           {{ old('factura_electronica', $empresa->factura_electronica) ? 'checked':'' }}>
                    <label for="factura_electronica" class="text-sm text-slate-300 cursor-pointer">
                        Habilitado para <strong>Factura Electrónica DIAN</strong>
                    </label>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                            Prefijo Factura
                        </label>
                        <input type="text" name="prefijo_factura"
                               value="{{ old('prefijo_factura', $empresa->prefijo_factura) }}"
                               placeholder="FE"
                               data-uppercase
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                      text-sm placeholder-slate-600 focus:outline-none focus:border-amber-500"
                               style="color:#e2e8f0">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                            N° Resolución
                        </label>
                        <input type="text" name="resolucion_numero"
                               value="{{ old('resolucion_numero', $empresa->resolucion_numero) }}"
                               placeholder="18764030"
                               data-numeric
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                      text-sm placeholder-slate-600 focus:outline-none focus:border-amber-500"
                               style="color:#e2e8f0">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                            Fecha Resolución
                        </label>
                        <input type="date" name="resolucion_fecha"
                               value="{{ old('resolucion_fecha', $empresa->resolucion_fecha?->format('Y-m-d')) }}"
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                      text-sm focus:outline-none focus:border-amber-500"
                               style="color:#e2e8f0">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                            Fecha Vencimiento
                        </label>
                        <input type="date" name="resolucion_vencimiento"
                               value="{{ old('resolucion_vencimiento', $empresa->resolucion_vencimiento?->format('Y-m-d')) }}"
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                      text-sm focus:outline-none focus:border-amber-500"
                               style="color:#e2e8f0">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                            Desde Consecutivo
                        </label>
                        <input type="text" name="consecutivo_desde"
                               value="{{ old('consecutivo_desde', $empresa->consecutivo_desde) }}"
                               data-numeric
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                      text-sm focus:outline-none focus:border-amber-500"
                               style="color:#e2e8f0">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                            Hasta Consecutivo
                        </label>
                        <input type="text" name="consecutivo_hasta"
                               value="{{ old('consecutivo_hasta', $empresa->consecutivo_hasta) }}"
                               data-numeric
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                      text-sm focus:outline-none focus:border-amber-500"
                               style="color:#e2e8f0">
                    </div>
                    <div class="sm:col-span-2 lg:col-span-3">
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                            Clave Técnica DIAN
                        </label>
                        <input type="text" name="clave_tecnica"
                               value="{{ old('clave_tecnica', $empresa->clave_tecnica) }}"
                               placeholder="CLAVE TÉCNICA PROPORCIONADA POR LA DIAN"
                               data-uppercase
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                      text-sm placeholder-slate-600 focus:outline-none focus:border-amber-500"
                               style="color:#e2e8f0">
                    </div>
                </div>
            </div>

            {{-- SECCIÓN 4: Impuestos por defecto --}}
            <div class="bg-[#141c2e] border border-[#1e2d47] rounded-2xl p-6">
                <h2 class="font-display font-bold text-base mb-4 flex items-center gap-2">
                    <span class="w-6 h-6 bg-amber-500 rounded-lg flex items-center justify-center
                                 text-black text-xs font-black">4</span>
                    Impuestos por Defecto
                </h2>
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                            % IVA por Defecto
                        </label>
                        <select name="iva_defecto"
                                class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                       text-sm focus:outline-none focus:border-amber-500"
                                style="color:#e2e8f0">
                            <option value="0"  {{ old('iva_defecto',$empresa->iva_defecto)==0  ? 'selected':'' }}>0% - Excluido</option>
                            <option value="5"  {{ old('iva_defecto',$empresa->iva_defecto)==5  ? 'selected':'' }}>5%</option>
                            <option value="19" {{ old('iva_defecto',$empresa->iva_defecto)==19 ? 'selected':'' }}>19% - General</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                            % ReteFuente por Defecto
                        </label>
                        <input type="text" inputmode="decimal" name="retefuente_defecto"
                               value="{{ old('retefuente_defecto', $empresa->retefuente_defecto) }}"
                               data-numeric
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                      text-sm focus:outline-none focus:border-amber-500"
                               style="color:#e2e8f0">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                            % ReteICA por Defecto
                        </label>
                        <input type="text" inputmode="decimal" name="reteica_defecto"
                               value="{{ old('reteica_defecto', $empresa->reteica_defecto) }}"
                               data-numeric
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                      text-sm focus:outline-none focus:border-amber-500"
                               style="color:#e2e8f0">
                    </div>
                </div>
            </div>

            {{-- SECCIÓN 5: Textos --}}
            <div class="bg-[#141c2e] border border-[#1e2d47] rounded-2xl p-6">
                <h2 class="font-display font-bold text-base mb-4 flex items-center gap-2">
                    <span class="w-6 h-6 bg-amber-500 rounded-lg flex items-center justify-center
                                 text-black text-xs font-black">5</span>
                    Textos de Factura
                </h2>
                <div class="space-y-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                            Pie de Página de Factura
                        </label>
                        <textarea name="pie_factura" rows="2"
                                  placeholder="TEXTO QUE APARECE AL PIE DE CADA FACTURA..."
                                  data-uppercase
                                  class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                         text-sm placeholder-slate-600 focus:outline-none focus:border-amber-500 resize-none"
                                  style="color:#e2e8f0">{{ old('pie_factura', $empresa->pie_factura) }}</textarea>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                            Términos y Condiciones
                        </label>
                        <textarea name="terminos_condiciones" rows="3"
                                  placeholder="TÉRMINOS Y CONDICIONES DE VENTA..."
                                  data-uppercase
                                  class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                                         text-sm placeholder-slate-600 focus:outline-none focus:border-amber-500 resize-none"
                                  style="color:#e2e8f0">{{ old('terminos_condiciones', $empresa->terminos_condiciones) }}</textarea>
                    </div>
                </div>
            </div>

        </div>

        {{-- COLUMNA DERECHA --}}
        <div class="space-y-4">

            {{-- Logo --}}
            <div class="bg-[#141c2e] border border-[#1e2d47] rounded-2xl p-6">
                <h3 class="font-display font-bold text-base mb-4 flex items-center gap-2">
                    <i class="fas fa-image text-amber-500 text-sm"></i>
                    Logo de la Empresa
                </h3>

                {{-- Preview actual --}}
                <div class="flex flex-col items-center mb-4">
                    @if($empresa->logo)
                    <div class="relative mb-3">
                        <img src="{{ Storage::url($empresa->logo) }}"
                             alt="Logo"
                             class="w-32 h-32 object-contain rounded-xl bg-white p-2">
                        <form method="POST" action="{{ route('empresa.logo.delete') }}"
                              class="absolute -top-2 -right-2"
                              onsubmit="return confirm('¿Eliminar el logo?')">
                            @csrf @method('DELETE')
                            <button type="submit"
                                    class="w-6 h-6 bg-red-500 text-white rounded-full
                                           flex items-center justify-center text-xs
                                           hover:bg-red-600 transition-colors">
                                <i class="fas fa-times"></i>
                            </button>
                        </form>
                    </div>
                    @else
                    <div class="w-32 h-32 bg-[#1a2235] border-2 border-dashed border-[#1e2d47]
                                rounded-xl flex flex-col items-center justify-center mb-3
                                text-slate-600">
                        <i class="fas fa-image text-3xl mb-2"></i>
                        <span class="text-xs">Sin logo</span>
                    </div>
                    @endif
                </div>

                <label class="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                    Subir Logo <span class="text-slate-600">(PNG, JPG máx 2MB)</span>
                </label>
                <input type="file" name="logo" accept="image/*"
                       class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                              text-sm text-slate-400 focus:outline-none focus:border-amber-500
                              file:mr-3 file:py-1 file:px-3 file:rounded-lg file:border-0
                              file:text-xs file:font-semibold file:bg-amber-500 file:text-black
                              hover:file:bg-amber-600 cursor-pointer">
            </div>

            {{-- Info resolución --}}
            <div class="bg-[#141c2e] border border-[#1e2d47] rounded-2xl p-5">
                <h3 class="font-display font-bold text-sm mb-4 flex items-center gap-2">
                    <i class="fas fa-file-contract text-amber-500"></i>
                    Estado Resolución DIAN
                </h3>
                @if($empresa->resolucion_numero)
                <div class="space-y-3">
                    <div>
                        <div class="text-xs text-slate-500 uppercase tracking-wider mb-1">Resolución</div>
                        <div class="text-sm font-semibold" style="color:#e2e8f0">
                            {{ number_format($empresa->resolucion_numero, 0, ',', '.') }}
                        </div>
                    </div>
                    @if($empresa->resolucion_vencimiento)
                    <div>
                        <div class="text-xs text-slate-500 uppercase tracking-wider mb-1">Vencimiento</div>
                        <div class="text-sm font-semibold
                            {{ $empresa->resolucion_vigente ? 'text-emerald-500' : 'text-red-400' }}">
                            {{ $empresa->resolucion_vencimiento->format('d/m/Y') }}
                        </div>
                    </div>
                    <div>
                        <div class="text-xs text-slate-500 uppercase tracking-wider mb-1">Estado</div>
                        @if($empresa->resolucion_vigente)
                        <span class="inline-flex items-center gap-1.5 text-xs font-semibold
                                     px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-500">
                            <span class="w-1.5 h-1.5 rounded-full bg-current animate-pulse"></span>
                            Vigente · {{ $empresa->dias_para_vencer }} días
                        </span>
                        @else
                        <span class="inline-flex items-center gap-1.5 text-xs font-semibold
                                     px-2.5 py-1 rounded-full bg-red-500/10 text-red-400">
                            <span class="w-1.5 h-1.5 rounded-full bg-current"></span>
                            Vencida
                        </span>
                        @endif
                    </div>
                    @endif
                    <div>
                        <div class="text-xs text-slate-500 uppercase tracking-wider mb-1">Consecutivos</div>
                        <div class="text-sm font-mono" style="color:#e2e8f0">
                            {{ number_format($empresa->consecutivo_desde) }}
                            — {{ number_format($empresa->consecutivo_hasta) }}
                        </div>
                        <div class="text-xs text-slate-500 mt-1">
                            Actual: {{ $empresa->consecutivo_actual }}
                        </div>
                    </div>
                </div>
                @else
                <div class="text-center py-4">
                    <i class="fas fa-exclamation-circle text-amber-500 text-2xl mb-2 block"></i>
                    <div class="text-xs text-slate-500">No hay resolución configurada</div>
                </div>
                @endif
            </div>

            {{-- Resumen empresa --}}
            <div class="bg-[#141c2e] border border-[#1e2d47] rounded-2xl p-5">
                <h3 class="font-display font-bold text-sm mb-4 flex items-center gap-2">
                    <i class="fas fa-building text-amber-500"></i>
                    Resumen
                </h3>
                <div class="space-y-3 text-sm">
                    <div class="flex items-center gap-2">
                        <div class="w-8 h-8 bg-amber-500 rounded-lg flex items-center justify-center
                                    font-black text-black text-xs flex-shrink-0">
                            {{ strtoupper(substr($empresa->razon_social, 0, 2)) }}
                        </div>
                        <div>
                            <div class="font-semibold text-xs" style="color:#e2e8f0">
                                {{ $empresa->razon_social }}
                            </div>
                            <div class="text-xs text-slate-500">NIT: {{ $empresa->nit_formateado }}</div>
                        </div>
                    </div>
                    @if($empresa->municipio)
                    <div class="flex items-center gap-2 text-xs text-slate-400">
                        <i class="fas fa-map-marker-alt w-4 text-slate-600"></i>
                        {{ $empresa->municipio }}{{ $empresa->departamento ? ', '.$empresa->departamento : '' }}
                    </div>
                    @endif
                    @if($empresa->email)
                    <div class="flex items-center gap-2 text-xs text-slate-400">
                        <i class="fas fa-envelope w-4 text-slate-600"></i>
                        {{ $empresa->email }}
                    </div>
                    @endif
                    @if($empresa->telefono)
                    <div class="flex items-center gap-2 text-xs text-slate-400">
                        <i class="fas fa-phone w-4 text-slate-600"></i>
                        {{ $empresa->telefono }}
                    </div>
                    @endif
                </div>
            </div>

            {{-- Botón guardar --}}
            <button type="submit"
                    class="w-full py-3 bg-amber-500 hover:bg-amber-600 text-black
                           font-bold rounded-xl transition-colors flex items-center justify-center gap-2">
                <i class="fas fa-save"></i> Guardar Configuración
            </button>

        </div>
    </div>
</form>

@endsection

@push('scripts')
<script>
// Mayúsculas
document.querySelectorAll('[data-uppercase]').forEach(el => {
    el.addEventListener('input', function() {
        const pos = this.selectionStart;
        this.value = this.value.toUpperCase();
        this.setSelectionRange(pos, pos);
    });
});

// Numérico
document.querySelectorAll('[data-numeric]').forEach(el => {
    el.addEventListener('input', function() {
        this.value = this.value.replace(/[^0-9.,]/g, '');
    });
});

// Preview logo al seleccionar archivo
document.querySelector('input[name="logo"]').addEventListener('change', function() {
    const file = this.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = e => {
        // Buscar si hay preview existente
        let img = document.querySelector('.logo-preview');
        if (!img) {
            img = document.createElement('img');
            img.className = 'logo-preview w-32 h-32 object-contain rounded-xl bg-white p-2 mx-auto mb-3';
            this.closest('.bg-\\[\\#141c2e\\]').querySelector('.flex.flex-col').prepend(img);
        }
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
});
</script>
@endpush