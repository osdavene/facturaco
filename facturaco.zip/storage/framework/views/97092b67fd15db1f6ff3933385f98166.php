<!DOCTYPE html>
<?php $temaActual = auth()->check() ? (auth()->user()->tema ?? 'dark') : 'dark'; ?>
<html lang="es" class="<?php echo e($temaActual === 'light' ? '' : 'dark'); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name')); ?> — <?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="bg-[#0b0f1a] text-slate-200 font-sans">

    
    <div id="overlay" onclick="closeSidebar()"
         class="hidden fixed inset-0 bg-black/50 z-[99] lg:hidden"></div>

    <div class="flex min-h-screen">

        
        <aside id="sidebar"
               class="fixed top-0 left-0 h-full w-64 bg-[#111827] border-r border-[#1e2d47]
                      flex flex-col z-[100]
                      -translate-x-full lg:translate-x-0 transition-transform duration-300">

            
            <?php $emp = \App\Models\Empresa::obtener(); ?>
            <div class="px-6 py-5 border-b border-[#1e2d47]">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 bg-amber-500 rounded-xl flex items-center justify-center
                                font-display font-black text-black text-lg flex-shrink-0 overflow-hidden">
                        <?php if($emp->logo): ?>
                            <img src="<?php echo e(Storage::url($emp->logo)); ?>"
                                 class="w-10 h-10 object-contain" alt="Logo">
                        <?php else: ?>
                            FC
                        <?php endif; ?>
                    </div>
                    <div class="min-w-0">
                        <div class="font-display font-black text-xl text-white leading-tight">
                            Factura<span class="text-amber-500">CO</span>
                        </div>
                        <div class="text-[10px] text-slate-500 tracking-wide truncate">
                            <?php echo e($emp->nombre_comercial ?: $emp->razon_social); ?>

                        </div>
                    </div>
                </div>
            </div>

            
            <div class="px-3 py-2.5 border-b border-[#1e2d47] lg:hidden">
                <button onclick="closeSidebar(); setTimeout(() => document.getElementById('busqueda-global').focus(), 300);"
                        class="w-full flex items-center gap-2 bg-[#1a2235] border border-[#1e2d47]
                               rounded-xl px-3 py-2 text-sm text-slate-500
                               hover:border-amber-500/50 transition-colors">
                    <i class="fas fa-search text-xs"></i>
                    <span>Buscar en el sistema...</span>
                    <span class="ml-auto text-[10px] bg-[#141c2e] px-1.5 py-0.5 rounded text-slate-600">
                        Ctrl+K
                    </span>
                </button>
            </div>

            
            <nav class="flex-1 overflow-y-auto py-4 px-3">

                
                <?php if (isset($component)) { $__componentOriginal460a283b8831bc43d8ca37a2ac46781c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal460a283b8831bc43d8ca37a2ac46781c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-section','data' => ['label' => 'Principal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Principal']); ?>
                    <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['href' => ''.e(route('dashboard')).'','icon' => 'fa-chart-line','active' => request()->routeIs('dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('dashboard')).'','icon' => 'fa-chart-line','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('dashboard'))]); ?>
                        Dashboard
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['href' => ''.e(route('facturas.index')).'','icon' => 'fa-file-invoice','active' => request()->routeIs('facturas.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('facturas.index')).'','icon' => 'fa-file-invoice','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('facturas.*'))]); ?>
                        Facturación
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['href' => ''.e(route('cotizaciones.index')).'','icon' => 'fa-file-alt','active' => request()->routeIs('cotizaciones.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('cotizaciones.index')).'','icon' => 'fa-file-alt','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('cotizaciones.*'))]); ?>
                        Cotizaciones
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['href' => ''.e(route('remisiones.index')).'','icon' => 'fa-receipt','active' => request()->routeIs('remisiones.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('remisiones.index')).'','icon' => 'fa-receipt','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('remisiones.*'))]); ?>
                        Remisiones
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal460a283b8831bc43d8ca37a2ac46781c)): ?>
<?php $attributes = $__attributesOriginal460a283b8831bc43d8ca37a2ac46781c; ?>
<?php unset($__attributesOriginal460a283b8831bc43d8ca37a2ac46781c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal460a283b8831bc43d8ca37a2ac46781c)): ?>
<?php $component = $__componentOriginal460a283b8831bc43d8ca37a2ac46781c; ?>
<?php unset($__componentOriginal460a283b8831bc43d8ca37a2ac46781c); ?>
<?php endif; ?>

                
                <?php if (isset($component)) { $__componentOriginal460a283b8831bc43d8ca37a2ac46781c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal460a283b8831bc43d8ca37a2ac46781c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-section','data' => ['label' => 'Gestión']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Gestión']); ?>
                    <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['href' => ''.e(route('inventario.index')).'','icon' => 'fa-boxes','active' => request()->routeIs('inventario.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('inventario.index')).'','icon' => 'fa-boxes','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('inventario.*'))]); ?>
                        Inventario
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['href' => ''.e(route('clientes.index')).'','icon' => 'fa-users','active' => request()->routeIs('clientes.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('clientes.index')).'','icon' => 'fa-users','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('clientes.*'))]); ?>
                        Clientes
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['href' => ''.e(route('proveedores.index')).'','icon' => 'fa-truck','active' => request()->routeIs('proveedores.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('proveedores.index')).'','icon' => 'fa-truck','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('proveedores.*'))]); ?>
                        Proveedores
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['href' => ''.e(route('ordenes.index')).'','icon' => 'fa-shopping-cart','active' => request()->routeIs('ordenes.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('ordenes.index')).'','icon' => 'fa-shopping-cart','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('ordenes.*'))]); ?>
                        Órdenes de Compra
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal460a283b8831bc43d8ca37a2ac46781c)): ?>
<?php $attributes = $__attributesOriginal460a283b8831bc43d8ca37a2ac46781c; ?>
<?php unset($__attributesOriginal460a283b8831bc43d8ca37a2ac46781c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal460a283b8831bc43d8ca37a2ac46781c)): ?>
<?php $component = $__componentOriginal460a283b8831bc43d8ca37a2ac46781c; ?>
<?php unset($__componentOriginal460a283b8831bc43d8ca37a2ac46781c); ?>
<?php endif; ?>

                
                <?php if (isset($component)) { $__componentOriginal460a283b8831bc43d8ca37a2ac46781c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal460a283b8831bc43d8ca37a2ac46781c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-section','data' => ['label' => 'Finanzas']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Finanzas']); ?>
                    <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['href' => ''.e(route('recibos.index')).'','icon' => 'fa-hand-holding-usd','active' => request()->routeIs('recibos.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('recibos.index')).'','icon' => 'fa-hand-holding-usd','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('recibos.*'))]); ?>
                        Recibos de Caja
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['href' => ''.e(route('reportes.index')).'','icon' => 'fa-chart-bar','active' => request()->routeIs('reportes.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('reportes.index')).'','icon' => 'fa-chart-bar','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('reportes.*'))]); ?>
                        Reportes
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['href' => ''.e(route('impuestos.index')).'','icon' => 'fa-percent','active' => request()->routeIs('impuestos.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('impuestos.index')).'','icon' => 'fa-percent','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('impuestos.*'))]); ?>
                        Impuestos / DIAN
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal460a283b8831bc43d8ca37a2ac46781c)): ?>
<?php $attributes = $__attributesOriginal460a283b8831bc43d8ca37a2ac46781c; ?>
<?php unset($__attributesOriginal460a283b8831bc43d8ca37a2ac46781c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal460a283b8831bc43d8ca37a2ac46781c)): ?>
<?php $component = $__componentOriginal460a283b8831bc43d8ca37a2ac46781c; ?>
<?php unset($__componentOriginal460a283b8831bc43d8ca37a2ac46781c); ?>
<?php endif; ?>

                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver usuarios')): ?>
                <?php if (isset($component)) { $__componentOriginal460a283b8831bc43d8ca37a2ac46781c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal460a283b8831bc43d8ca37a2ac46781c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-section','data' => ['label' => 'Configuración']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Configuración']); ?>
                    <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['href' => ''.e(route('usuarios.index')).'','icon' => 'fa-users-cog','active' => request()->routeIs('usuarios.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('usuarios.index')).'','icon' => 'fa-users-cog','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('usuarios.*'))]); ?>
                        Usuarios & Roles
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['href' => ''.e(route('empresa.index')).'','icon' => 'fa-building','active' => request()->routeIs('empresa.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('empresa.index')).'','icon' => 'fa-building','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('empresa.*'))]); ?>
                        Empresa
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal460a283b8831bc43d8ca37a2ac46781c)): ?>
<?php $attributes = $__attributesOriginal460a283b8831bc43d8ca37a2ac46781c; ?>
<?php unset($__attributesOriginal460a283b8831bc43d8ca37a2ac46781c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal460a283b8831bc43d8ca37a2ac46781c)): ?>
<?php $component = $__componentOriginal460a283b8831bc43d8ca37a2ac46781c; ?>
<?php unset($__componentOriginal460a283b8831bc43d8ca37a2ac46781c); ?>
<?php endif; ?>
                <?php endif; ?>

            </nav>

            
            <div class="p-4 border-t border-[#1e2d47]">
                <div class="flex items-center gap-3">
                    <a href="<?php echo e(route('perfil.index')); ?>"
                    class="flex-shrink-0 relative group">
                        <img src="<?php echo e(auth()->user()->avatar_url); ?>"
                            class="w-9 h-9 rounded-xl object-cover border-2 border-transparent
                                    group-hover:border-amber-500 transition-colors"
                            alt="<?php echo e(auth()->user()->name); ?>">
                        <div class="absolute inset-0 rounded-xl bg-amber-500/0 group-hover:bg-amber-500/10
                                    transition-colors flex items-center justify-center">
                        </div>
                    </a>
                    <a href="<?php echo e(route('perfil.index')); ?>" class="flex-1 min-w-0 hover:opacity-80 transition-opacity">
                        <div class="text-sm font-semibold text-white truncate">
                            <?php echo e(auth()->user()->name); ?>

                        </div>
                        <div class="text-xs text-slate-500 capitalize truncate">
                            <?php echo e(auth()->user()->cargo ?? auth()->user()->getRoleNames()->first() ?? 'Sin rol'); ?>

                        </div>
                    </a>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" title="Cerrar sesión"
                                class="w-8 h-8 rounded-lg bg-[#1a2235] border border-[#1e2d47]
                                    flex items-center justify-center flex-shrink-0
                                    text-slate-500 hover:text-red-400 hover:border-red-500/50
                                    transition-colors">
                            <i class="fas fa-sign-out-alt text-xs"></i>
                        </button>
                    </form>
                </div>
            </div>
        </aside>
        

        
        <div class="flex-1 flex flex-col lg:ml-64 min-w-0">

            
            <header class="sticky top-0 z-50 bg-[#111827]/95 backdrop-blur
                           border-b border-[#1e2d47] px-4 lg:px-7 py-3
                           flex items-center gap-3">

                
                <button onclick="toggleSidebar()"
                        class="lg:hidden text-slate-300 text-xl hover:text-white
                               transition-colors flex-shrink-0">
                    <i class="fas fa-bars"></i>
                </button>

                
                <div class="font-display font-bold text-lg truncate min-w-0 hidden lg:block">
                    <?php echo $__env->yieldContent('page-title', 'Dashboard'); ?>
                </div>

                
                <div class="flex-1 max-w-xs lg:max-w-md mx-0 lg:mx-4 relative"
                     id="busqueda-container">
                    <div class="relative">
                        <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2
                                  text-slate-500 text-sm pointer-events-none"></i>
                        <input type="text"
                               id="busqueda-global"
                               placeholder="Buscar... (Ctrl+K)"
                               autocomplete="off"
                               class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl
                                      pl-9 pr-8 py-2 text-sm placeholder-slate-600
                                      focus:outline-none focus:border-amber-500 transition-all"
                               style="color:#e2e8f0">
                        <div id="busqueda-loading"
                             class="absolute right-3 top-1/2 -translate-y-1/2 hidden">
                            <i class="fas fa-spinner fa-spin text-slate-500 text-xs"></i>
                        </div>
                        <button id="busqueda-clear"
                                onclick="limpiarBusqueda()"
                                class="absolute right-3 top-1/2 -translate-y-1/2 hidden
                                       text-slate-500 hover:text-slate-300 transition-colors">
                            <i class="fas fa-times text-xs"></i>
                        </button>
                    </div>
                    
                    <div id="busqueda-resultados"
                         class="absolute top-full left-0 right-0 mt-1.5 bg-[#141c2e]
                                border border-[#1e2d47] rounded-xl shadow-2xl z-[200]
                                hidden overflow-hidden max-h-[70vh] overflow-y-auto">
                    </div>
                </div>

                
                <div class="ml-auto flex items-center gap-2 flex-shrink-0">

                    
                    <?php if($emp->resolucion_vencimiento): ?>
                        <?php if(!$emp->resolucion_vigente): ?>
                        <a href="<?php echo e(route('empresa.index')); ?>"
                           class="hidden lg:flex items-center gap-2 text-xs text-red-400
                                  bg-red-500/10 border border-red-500/30 px-3 py-1.5
                                  rounded-lg hover:bg-red-500/15 transition-colors">
                            <div class="w-1.5 h-1.5 rounded-full bg-red-500 flex-shrink-0"></div>
                            DIAN Vencida
                        </a>
                        <?php elseif($emp->dias_para_vencer <= 30): ?>
                        <a href="<?php echo e(route('empresa.index')); ?>"
                           class="hidden lg:flex items-center gap-2 text-xs text-amber-500
                                  bg-amber-500/10 border border-amber-500/30 px-3 py-1.5
                                  rounded-lg hover:bg-amber-500/15 transition-colors">
                            <div class="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse flex-shrink-0"></div>
                            DIAN <?php echo e($emp->dias_para_vencer); ?>d
                        </a>
                        <?php else: ?>
                        <div class="hidden lg:flex items-center gap-2 text-xs text-emerald-500">
                            <div class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                            DIAN Vigente
                        </div>
                        <?php endif; ?>
                    <?php else: ?>
                    <a href="<?php echo e(route('empresa.index')); ?>"
                       class="hidden lg:flex items-center gap-2 text-xs text-slate-500
                              hover:text-amber-500 transition-colors">
                        <div class="w-1.5 h-1.5 rounded-full bg-slate-600"></div>
                        Sin resolución
                    </a>
                    <?php endif; ?>
                    
                    
                    <a href="<?php echo e(route('perfil.index')); ?>"
                    class="hidden lg:flex items-center gap-2 text-slate-400 hover:text-slate-200
                            transition-colors text-sm">
                        <img src="<?php echo e(auth()->user()->avatar_url); ?>"
                            class="w-7 h-7 rounded-lg object-cover border border-[#1e2d47]"
                            alt="<?php echo e(auth()->user()->name); ?>">
                    </a>

                    
                    <a href="<?php echo e(route('facturas.create')); ?>"
                       class="flex items-center gap-2 bg-amber-500 hover:bg-amber-600
                              text-black font-semibold text-sm px-3 lg:px-4 py-2
                              rounded-lg transition-colors flex-shrink-0">
                        <i class="fas fa-plus"></i>
                        <span class="hidden sm:inline">Nueva Factura</span>
                    </a>

                    
                    <?php $esOscuro = ($temaActual ?? 'dark') === 'dark'; ?>
                    <form method="POST" action="<?php echo e(route('tema.cambiar')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="tema" value="<?php echo e($esOscuro ? 'light' : 'dark'); ?>">
                        <button type="submit"
                                title="<?php echo e($esOscuro ? 'Cambiar a tema claro' : 'Cambiar a tema oscuro'); ?>"
                                class="w-9 h-9 bg-[#1a2235] border border-[#1e2d47] rounded-lg
                                    flex items-center justify-center transition-colors
                                    text-slate-400 hover:text-amber-500 hover:border-amber-500/50">
                            <i class="fas <?php echo e($esOscuro ? 'fa-sun' : 'fa-moon'); ?> text-sm"></i>
                        </button>
                    </form>

                    
                    <div class="relative group">
                        <button class="relative w-9 h-9 bg-[#1a2235] border border-[#1e2d47]
                                       rounded-lg flex items-center justify-center
                                       text-slate-400 hover:text-white hover:border-slate-500
                                       transition-colors">
                            <i class="fas fa-bell text-sm"></i>
                            <?php
                                $hayAlertas = ($emp->resolucion_vencimiento &&
                                              (!$emp->resolucion_vigente || $emp->dias_para_vencer <= 30))
                                           || !$emp->resolucion_numero;
                            ?>
                            <?php if($hayAlertas): ?>
                            <span class="absolute top-1.5 right-1.5 w-1.5 h-1.5
                                         bg-red-500 rounded-full"></span>
                            <?php endif; ?>
                        </button>

                        
                        <div class="absolute right-0 top-full mt-2 w-72 bg-[#141c2e]
                                    border border-[#1e2d47] rounded-xl shadow-xl z-50
                                    hidden group-hover:block">
                            <div class="px-4 py-3 border-b border-[#1e2d47]">
                                <div class="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                                    Notificaciones
                                </div>
                            </div>
                            <div class="py-1">
                                <?php if(!$emp->resolucion_numero): ?>
                                <a href="<?php echo e(route('empresa.index')); ?>"
                                   class="flex items-start gap-3 px-4 py-3 hover:bg-[#1a2235] transition-colors">
                                    <div class="w-8 h-8 bg-amber-500/10 rounded-lg flex items-center
                                                justify-center text-amber-500 flex-shrink-0 mt-0.5">
                                        <i class="fas fa-exclamation text-xs"></i>
                                    </div>
                                    <div>
                                        <div class="text-xs font-semibold" style="color:#e2e8f0">Sin resolución DIAN</div>
                                        <div class="text-xs text-slate-500 mt-0.5">Configura tu resolución en Empresa</div>
                                    </div>
                                </a>
                                <?php elseif(!$emp->resolucion_vigente): ?>
                                <a href="<?php echo e(route('empresa.index')); ?>"
                                   class="flex items-start gap-3 px-4 py-3 hover:bg-[#1a2235] transition-colors">
                                    <div class="w-8 h-8 bg-red-500/10 rounded-lg flex items-center
                                                justify-center text-red-400 flex-shrink-0 mt-0.5">
                                        <i class="fas fa-times text-xs"></i>
                                    </div>
                                    <div>
                                        <div class="text-xs font-semibold text-red-400">Resolución DIAN vencida</div>
                                        <div class="text-xs text-slate-500 mt-0.5">
                                            Venció el <?php echo e($emp->resolucion_vencimiento->format('d/m/Y')); ?>

                                        </div>
                                    </div>
                                </a>
                                <?php elseif($emp->dias_para_vencer <= 30): ?>
                                <a href="<?php echo e(route('empresa.index')); ?>"
                                   class="flex items-start gap-3 px-4 py-3 hover:bg-[#1a2235] transition-colors">
                                    <div class="w-8 h-8 bg-amber-500/10 rounded-lg flex items-center
                                                justify-center text-amber-500 flex-shrink-0 mt-0.5">
                                        <i class="fas fa-clock text-xs"></i>
                                    </div>
                                    <div>
                                        <div class="text-xs font-semibold text-amber-500">Resolución por vencer</div>
                                        <div class="text-xs text-slate-500 mt-0.5">
                                            Vence en <?php echo e($emp->dias_para_vencer); ?> días
                                        </div>
                                    </div>
                                </a>
                                <?php else: ?>
                                <div class="px-4 py-6 text-center text-slate-500 text-xs">
                                    <i class="fas fa-check-circle text-emerald-500 text-lg mb-2 block"></i>
                                    Todo en orden
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    

                </div>
                

            </header>
            

            
            <main class="flex-1 p-4 lg:p-7">
                <?php echo $__env->yieldContent('content'); ?>
            </main>

            
            <footer class="px-4 lg:px-7 py-3 border-t border-[#1e2d47]">
                <div class="flex flex-col sm:flex-row items-center justify-between gap-2">
                    <span class="text-xs text-slate-600">
                        FacturaCO © <?php echo e(now()->year); ?> · <?php echo e($emp->razon_social); ?>

                    </span>
                    <span class="text-xs text-slate-600">
                        NIT: <?php echo e($emp->nit_formateado); ?>

                        <?php if($emp->municipio): ?> · <?php echo e($emp->municipio); ?> <?php endif; ?>
                    </span>
                </div>
            </footer>

        </div>
        

    </div>
    

    
    <nav class="bottom-nav lg:hidden">
        <?php
        $navItems = [
            ['route' => 'dashboard',        'icon' => 'fa-chart-line',   'label' => 'Inicio'],
            ['route' => 'facturas.index',   'icon' => 'fa-file-invoice', 'label' => 'Facturas'],
            ['route' => 'clientes.index',   'icon' => 'fa-users',        'label' => 'Clientes'],
            ['route' => 'inventario.index', 'icon' => 'fa-boxes',        'label' => 'Inventario'],
            ['route' => 'reportes.index',   'icon' => 'fa-chart-bar',    'label' => 'Reportes'],
        ];
        ?>

        <?php $__currentLoopData = $navItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $isActive = request()->routeIs($item['route'].'*'); ?>
        <a href="<?php echo e(route($item['route'])); ?>"
           class="flex-1 flex flex-col items-center justify-center py-1 gap-0.5 transition-colors
                  <?php echo e($isActive ? 'text-amber-500' : 'text-slate-500 hover:text-slate-300'); ?>">
            <i class="fas <?php echo e($item['icon']); ?> text-lg"></i>
            <span class="text-[9px] font-semibold tracking-wide"><?php echo e($item['label']); ?></span>
            <?php if($isActive): ?>
            <div class="w-1 h-1 rounded-full bg-amber-500 mt-0.5"></div>
            <?php endif; ?>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <a href="<?php echo e(route('facturas.create')); ?>"
           class="flex-shrink-0 w-14 h-14 bg-amber-500 rounded-2xl flex items-center
                  justify-center shadow-lg shadow-amber-500/30 -mt-5
                  hover:bg-amber-600 transition-colors">
            <i class="fas fa-plus text-black text-xl"></i>
        </a>
    </nav>

    
    <script>
    // ── Sidebar toggle ────────────────────────
    function toggleSidebar() {
        document.getElementById('sidebar').classList.toggle('-translate-x-full');
        document.getElementById('overlay').classList.toggle('hidden');
    }
    function closeSidebar() {
        document.getElementById('sidebar').classList.add('-translate-x-full');
        document.getElementById('overlay').classList.add('hidden');
    }

    // ── Búsqueda Global ───────────────────────
    (function() {
        const input    = document.getElementById('busqueda-global');
        const dropdown = document.getElementById('busqueda-resultados');
        const loading  = document.getElementById('busqueda-loading');
        const clearBtn = document.getElementById('busqueda-clear');
        let   timer    = null;

        if (!input) return;

        const colores = {
            amber:   '#f59e0b', blue:    '#3b82f6',
            emerald: '#10b981', purple:  '#8b5cf6',
            cyan:    '#06b6d4', orange:  '#f97316',
            green:   '#22c55e', slate:   '#64748b',
        };

        input.addEventListener('input', function() {
            const q = this.value.trim();
            clearTimeout(timer);
            clearBtn.classList.toggle('hidden', q.length === 0);

            if (q.length < 2) {
                dropdown.classList.add('hidden');
                dropdown.innerHTML = '';
                loading.classList.add('hidden');
                return;
            }

            loading.classList.remove('hidden');
            clearBtn.classList.add('hidden');

            timer = setTimeout(async () => {
                try {
                    const res  = await fetch(`/busqueda?q=${encodeURIComponent(q)}`, {
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                            'Accept': 'application/json',
                        }
                    });
                    const data = await res.json();

                    loading.classList.add('hidden');
                    clearBtn.classList.remove('hidden');

                    if (!data.resultados.length) {
                        dropdown.innerHTML = `
                            <div class="px-5 py-8 text-center">
                                <i class="fas fa-search text-slate-600 text-2xl mb-2 block"></i>
                                <div class="text-slate-500 text-sm">
                                    Sin resultados para
                                    "<strong class="text-slate-400">${q}</strong>"
                                </div>
                            </div>`;
                        dropdown.classList.remove('hidden');
                        return;
                    }

                    // Agrupar por tipo
                    const grupos = {};
                    data.resultados.forEach(r => {
                        if (!grupos[r.tipo]) grupos[r.tipo] = [];
                        grupos[r.tipo].push(r);
                    });

                    let html = '';
                    Object.entries(grupos).forEach(([tipo, items]) => {
                        html += `
                            <div class="px-4 py-2 border-b border-[#1e2d47]/50 bg-[#1a2235]/30">
                                <div class="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                                    ${tipo}s
                                </div>
                            </div>`;
                        items.forEach(item => {
                            const color = colores[item.color] || '#64748b';
                            html += `
                            <a href="${item.url}"
                               class="flex items-center gap-3 px-4 py-3
                                      hover:bg-[#1a2235] transition-colors
                                      border-b border-[#1e2d47]/30 last:border-0 resultado-item">
                                <div class="w-8 h-8 rounded-lg flex items-center
                                            justify-center flex-shrink-0"
                                     style="background:${color}18; color:${color}">
                                    <i class="fas ${item.icono} text-xs"></i>
                                </div>
                                <div class="flex-1 min-w-0">
                                    <div class="text-sm font-semibold truncate"
                                         style="color:#e2e8f0">${item.titulo}</div>
                                    <div class="text-xs text-slate-500 truncate">${item.subtitulo}</div>
                                </div>
                                <div class="text-xs text-slate-500 flex-shrink-0 text-right ml-2">
                                    ${item.detalle}
                                </div>
                            </a>`;
                        });
                    });

                    html += `
                        <div class="px-4 py-2.5 border-t border-[#1e2d47] bg-[#1a2235]/50">
                            <div class="text-xs text-slate-500 text-center">
                                ${data.total} resultado${data.total !== 1 ? 's' : ''}
                                para "<span class="text-slate-400">${q}</span>"
                            </div>
                        </div>`;

                    dropdown.innerHTML = html;
                    dropdown.classList.remove('hidden');

                } catch(err) {
                    loading.classList.add('hidden');
                    clearBtn.classList.remove('hidden');
                    console.error('Error búsqueda:', err);
                }
            }, 350);
        });

        // Escape cierra
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') limpiarBusqueda();
            if (e.key === 'Enter') {
                const primer = dropdown.querySelector('.resultado-item');
                if (primer) primer.click();
            }
        });

        // Cerrar al clic fuera
        document.addEventListener('click', function(e) {
            if (!e.target.closest('#busqueda-container')) {
                dropdown.classList.add('hidden');
            }
        });

        // Atajo Ctrl+K / Cmd+K
        document.addEventListener('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                input.focus();
                input.select();
            }
        });
    })();

    function limpiarBusqueda() {
        const input    = document.getElementById('busqueda-global');
        const dropdown = document.getElementById('busqueda-resultados');
        const clearBtn = document.getElementById('busqueda-clear');
        if (input)    { input.value = ''; input.blur(); }
        if (dropdown)   dropdown.classList.add('hidden');
        if (clearBtn)   clearBtn.classList.add('hidden');
    }
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html><?php /**PATH C:\Proyectos\facturaco\resources\views/layouts/app.blade.php ENDPATH**/ ?>