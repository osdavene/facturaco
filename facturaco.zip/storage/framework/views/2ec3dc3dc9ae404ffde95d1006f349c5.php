<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['href' => '#', 'icon' => '', 'active' => false, 'badge' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['href' => '#', 'icon' => '', 'active' => false, 'badge' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<a href="<?php echo e($href); ?>"
   class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm mb-0.5 transition-all relative
          <?php echo e($active
              ? 'bg-amber-500/10 text-amber-500 font-medium'
              : 'text-slate-500 hover:bg-[#1a2235] hover:text-slate-200'); ?>">

    <?php if($active): ?>
        <span class="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-3/5
                     bg-amber-500 rounded-r"></span>
    <?php endif; ?>

    <i class="fas <?php echo e($icon); ?> w-4 text-center text-[15px]"></i>
    <span class="flex-1"><?php echo e($slot); ?></span>

    <?php if($badge): ?>
        <span class="bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
            <?php echo e($badge); ?>

        </span>
    <?php endif; ?>
</a><?php /**PATH C:\Proyectos\facturaco\resources\views/components/nav-item.blade.php ENDPATH**/ ?>