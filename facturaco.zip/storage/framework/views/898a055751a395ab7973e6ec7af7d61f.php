
<?php $__env->startSection('title', 'Inventario'); ?>
<?php $__env->startSection('page-title', 'Inventario'); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400
            rounded-xl px-5 py-3 mb-5 flex items-center gap-3">
    <i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>


<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
    <div>
        <h1 class="font-display font-bold text-2xl">Inventario</h1>
        <p class="text-slate-500 text-sm mt-1">Gestiona tus productos y stock</p>
    </div>
    <a href="<?php echo e(route('inventario.create')); ?>"
       class="inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-600
              text-black font-semibold px-5 py-2.5 rounded-xl transition-colors">
        <i class="fas fa-plus"></i> Nuevo Producto
    </a>
</div>


<div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-5">
    <div class="bg-[#141c2e] border border-[#1e2d47] rounded-2xl p-5">
        <div class="flex items-center justify-between mb-2">
            <div class="text-xs text-slate-500 uppercase tracking-wider">Total Productos</div>
            <div class="w-8 h-8 bg-blue-500/10 rounded-lg flex items-center justify-center text-blue-400">
                <i class="fas fa-boxes text-sm"></i>
            </div>
        </div>
        <div class="font-display font-bold text-2xl"><?php echo e($totalProductos); ?></div>
    </div>
    <div class="bg-[#141c2e] border border-[#1e2d47] rounded-2xl p-5 cursor-pointer
                hover:border-amber-500/50 transition-colors"
         onclick="document.querySelector('[name=stock]').value='bajo'; document.querySelector('#filtros').submit()">
        <div class="flex items-center justify-between mb-2">
            <div class="text-xs text-slate-500 uppercase tracking-wider">Bajo Stock</div>
            <div class="w-8 h-8 bg-amber-500/10 rounded-lg flex items-center justify-center text-amber-500">
                <i class="fas fa-exclamation-triangle text-sm"></i>
            </div>
        </div>
        <div class="font-display font-bold text-2xl text-amber-500"><?php echo e($bajoStock); ?></div>
        <div class="text-xs text-slate-500 mt-1">Clic para filtrar</div>
    </div>
    <div class="bg-[#141c2e] border border-[#1e2d47] rounded-2xl p-5">
        <div class="flex items-center justify-between mb-2">
            <div class="text-xs text-slate-500 uppercase tracking-wider">Sin Stock</div>
            <div class="w-8 h-8 bg-red-500/10 rounded-lg flex items-center justify-center text-red-400">
                <i class="fas fa-times-circle text-sm"></i>
            </div>
        </div>
        <div class="font-display font-bold text-2xl text-red-400"><?php echo e($sinStock); ?></div>
    </div>
</div>


<form id="filtros" method="GET" action="<?php echo e(route('inventario.index')); ?>"
      class="bg-[#141c2e] border border-[#1e2d47] rounded-2xl p-4 mb-5">
    <input type="hidden" name="stock" value="<?php echo e(request('stock')); ?>">
    <div class="flex flex-col sm:flex-row gap-3">
        <div class="flex-1 relative">
            <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-sm"></i>
            <input type="text" name="buscar" value="<?php echo e(request('buscar')); ?>"
                   placeholder="Buscar por nombre, código..."
                   class="w-full bg-[#1a2235] border border-[#1e2d47] rounded-xl
                          pl-9 pr-4 py-2.5 text-sm text-slate-200 placeholder-slate-600
                          focus:outline-none focus:border-amber-500">
        </div>
        <select name="categoria_id"
                class="bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                       text-sm text-slate-300 focus:outline-none focus:border-amber-500">
            <option value="">Todas las categorías</option>
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($cat->id); ?>" <?php echo e(request('categoria_id')==$cat->id ? 'selected':''); ?>>
                <?php echo e($cat->nombre); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select name="estado"
                class="bg-[#1a2235] border border-[#1e2d47] rounded-xl px-4 py-2.5
                       text-sm text-slate-300 focus:outline-none focus:border-amber-500">
            <option value="">Todos</option>
            <option value="activo"   <?php echo e(request('estado')=='activo'   ? 'selected':''); ?>>Activos</option>
            <option value="inactivo" <?php echo e(request('estado')=='inactivo' ? 'selected':''); ?>>Inactivos</option>
        </select>
        <button type="submit"
                class="bg-amber-500 hover:bg-amber-600 text-black font-semibold
                       px-5 py-2.5 rounded-xl transition-colors whitespace-nowrap">
            <i class="fas fa-filter mr-2"></i>Filtrar
        </button>
        <?php if(request()->hasAny(['buscar','categoria_id','estado','stock'])): ?>
        <a href="<?php echo e(route('inventario.index')); ?>"
           class="bg-[#1a2235] border border-[#1e2d47] hover:border-red-500/50
                  text-slate-400 hover:text-red-400 px-4 py-2.5 rounded-xl
                  transition-colors text-sm flex items-center gap-2">
            <i class="fas fa-times"></i> Limpiar
        </a>
        <?php endif; ?>
    </div>
</form>


<div class="bg-[#141c2e] border border-[#1e2d47] rounded-2xl overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead>
                <tr class="border-b border-[#1e2d47]">
                    <th class="text-left text-[11px] font-semibold text-slate-500 uppercase tracking-wider px-5 py-3">Producto</th>
                    <th class="text-left text-[11px] font-semibold text-slate-500 uppercase tracking-wider px-3 py-3 hidden md:table-cell">Categoría</th>
                    <th class="text-right text-[11px] font-semibold text-slate-500 uppercase tracking-wider px-3 py-3">Stock</th>
                    <th class="text-right text-[11px] font-semibold text-slate-500 uppercase tracking-wider px-3 py-3 hidden sm:table-cell">Precio Venta</th>
                    <th class="text-left text-[11px] font-semibold text-slate-500 uppercase tracking-wider px-3 py-3 hidden lg:table-cell">Estado</th>
                    <th class="text-right text-[11px] font-semibold text-slate-500 uppercase tracking-wider px-5 py-3">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-b border-[#1e2d47]/50 hover:bg-[#1a2235]/50 transition-colors">

                    <td class="px-5 py-4">
                        <div class="flex items-center gap-3">
                            <div class="w-9 h-9 rounded-xl flex items-center justify-center
                                        font-bold text-xs text-white flex-shrink-0
                                        <?php echo e($producto->es_servicio
                                           ? 'bg-gradient-to-br from-purple-500 to-pink-600'
                                           : 'bg-gradient-to-br from-amber-500 to-orange-600'); ?>">
                                <i class="fas <?php echo e($producto->es_servicio ? 'fa-concierge-bell' : 'fa-box'); ?>"></i>
                            </div>
                            <div>
                                <div class="text-sm font-semibold"><?php echo e($producto->nombre); ?></div>
                                <div class="text-xs text-slate-500 font-mono"><?php echo e($producto->codigo); ?></div>
                            </div>
                        </div>
                    </td>

                    <td class="px-3 py-4 hidden md:table-cell">
                        <span class="text-xs bg-[#1a2235] px-2.5 py-1 rounded-full text-slate-400">
                            <?php echo e($producto->categoria->nombre ?? '—'); ?>

                        </span>
                    </td>

                    <td class="px-3 py-4 text-right">
                        <?php if($producto->es_servicio): ?>
                            <span class="text-xs text-slate-500">Servicio</span>
                        <?php else: ?>
                            <div class="font-display font-bold text-base
                                <?php echo e($producto->bajo_stock ? 'text-red-400' : 'text-slate-200'); ?>">
                                <?php echo e(number_format($producto->stock_actual, 0)); ?>

                            </div>
                            <div class="text-xs text-slate-600">
                                mín <?php echo e(number_format($producto->stock_minimo, 0)); ?>

                            </div>
                            <?php if($producto->bajo_stock): ?>
                            <div class="text-[10px] text-red-400 font-semibold">⚠ Bajo stock</div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>

                    <td class="px-3 py-4 text-right hidden sm:table-cell">
                        <div class="text-sm font-semibold">
                            $<?php echo e(number_format($producto->precio_venta, 0, ',', '.')); ?>

                        </div>
                        <div class="text-xs text-slate-500">IVA <?php echo e($producto->iva_pct); ?>%</div>
                    </td>

                    <td class="px-3 py-4 hidden lg:table-cell">
                        <span class="inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full
                            <?php echo e($producto->activo
                               ? 'bg-emerald-500/10 text-emerald-500'
                               : 'bg-red-500/10 text-red-400'); ?>">
                            <span class="w-1.5 h-1.5 rounded-full bg-current"></span>
                            <?php echo e($producto->activo ? 'Activo' : 'Inactivo'); ?>

                        </span>
                    </td>

                    <td class="px-5 py-4 text-right">
                        <div class="flex items-center justify-end gap-2">
                            <a href="<?php echo e(route('inventario.show', $producto)); ?>" title="Ver"
                               class="w-8 h-8 bg-[#1a2235] border border-[#1e2d47] rounded-lg
                                      flex items-center justify-center text-slate-400
                                      hover:text-blue-400 hover:border-blue-500/50 transition-colors">
                                <i class="fas fa-eye text-xs"></i>
                            </a>
                            <a href="<?php echo e(route('inventario.edit', $producto)); ?>" title="Editar"
                               class="w-8 h-8 bg-[#1a2235] border border-[#1e2d47] rounded-lg
                                      flex items-center justify-center text-slate-400
                                      hover:text-amber-500 hover:border-amber-500/50 transition-colors">
                                <i class="fas fa-pen text-xs"></i>
                            </a>
                            <form method="POST" action="<?php echo e(route('inventario.destroy', $producto)); ?>"
                                  onsubmit="return confirm('¿Eliminar <?php echo e($producto->nombre); ?>?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" title="Eliminar"
                                        class="w-8 h-8 bg-[#1a2235] border border-[#1e2d47] rounded-lg
                                               flex items-center justify-center text-slate-400
                                               hover:text-red-400 hover:border-red-500/50 transition-colors">
                                    <i class="fas fa-trash text-xs"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="px-5 py-16 text-center">
                        <div class="flex flex-col items-center gap-3">
                            <div class="w-14 h-14 bg-[#1a2235] rounded-2xl flex items-center
                                        justify-center text-slate-600 text-2xl">
                                <i class="fas fa-boxes"></i>
                            </div>
                            <div class="text-slate-500">No hay productos registrados</div>
                            <a href="<?php echo e(route('inventario.create')); ?>"
                               class="text-amber-500 hover:underline text-sm font-medium">
                                + Crear el primero
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($productos->hasPages()): ?>
    <div class="px-5 py-4 border-t border-[#1e2d47]">
        <?php echo e($productos->links()); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Proyectos\facturaco\resources\views/inventario/index.blade.php ENDPATH**/ ?>